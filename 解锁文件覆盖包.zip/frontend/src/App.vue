<script setup>
import {
  EventsEmit,
  EventsOff,
  EventsOn,
  Quit,Hide ,
  WindowFullscreen,
  WindowUnfullscreen,
  WindowSetTitle
} from '../wailsjs/runtime'
import {h, onBeforeMount, onBeforeUnmount, onMounted, ref, watch} from "vue";
import {RouterLink, useRoute, useRouter} from 'vue-router'
import {createDiscreteApi,darkTheme,lightTheme , NIcon, NText,NButton,NProgress,dateZhCN,zhCN} from 'naive-ui'
import {
  AlarmOutline,
  AnalyticsOutline,
  BarChartSharp, Bonfire, BonfireOutline, BookOutline, CalendarOutline, DiamondOutline, DocumentTextOutline, EaselSharp,
  ExpandOutline, Flag,
  Flame, FlameSharp, FlaskOutline, GlobeOutline, HomeOutline, InformationOutline,
  LogoGithub,
  ChatbubblesOutline,
  NewspaperOutline,
  NewspaperSharp, Notifications,
  PowerOutline, Pulse,
  ReorderTwoOutline,
  SettingsOutline, ServerOutline, ScaleOutline, Skull, SkullOutline, SkullSharp,
  SparklesOutline, FlashOutline, Star,
  StarOutline,
  StatsChartOutline, SwapHorizontalOutline,
  Wallet, WarningOutline, TimeOutline, SearchOutline, BookmarkOutline,
} from '@vicons/ionicons5'
import {AnalyzeSentiment, GetConfig, GetEffectiveSponsorVip, GetGroupList, GetVersionInfo, IsTradingTime, IsHKTradingTime, IsUSTradingTime, RestartApp} from "../wailsjs/go/main/App";
import FloatingAiAssistant from "./components/FloatingAiAssistant.vue";
import FloatingAgentAssistant from "./components/FloatingAgentAssistant.vue";
import SignalMonitorPanel from "./components/SignalMonitorPanel.vue";
import {Dragon, Fire, FirefoxBrowser, Gripfire, Robot} from "@vicons/fa";
import {Prompt, ReportAnalytics, ReportMoney, ReportSearch, TrendingUp} from "@vicons/tabler";
import {LocalFireDepartmentRound} from "@vicons/material";
import {AppsList20Regular, BoxSearch20Regular,SlideHide24Filled, CommentNote20Filled} from "@vicons/fluent";
import {FireFilled, MoneyCollectOutlined, NotificationFilled, StockOutlined} from "@vicons/antd";




const router = useRouter()
const loading = ref(true)
const loadingMsg = ref("加载数据中...")
const enableNews = ref(false)
const contentStyle = ref("")
const enableFund = ref(false)
// 「合约行情」菜单显隐：custom 编译隐藏（与"关于"页面同方向）；普通编译下
// 受设置页「启用合约行情」开关（enableContracts）控制
const enableContracts = ref(true)
const isCustomBuild = ref(false)
const enableAgent = ref(false)
const enableDarkTheme = ref(darkTheme)
const content = ref('未经授权,禁止商业目的!\n\n数据来源于网络,仅供参考;投资有风险,入市需谨慎')
const isFullscreen = ref(false)
const activeKey = ref('home')
const route = useRoute()
// 路由变化时同步菜单高亮（如重定向、前进/后退）
watch(() => route.name, (name) => {
  if (name && typeof name === 'string') {
    activeKey.value = name
  }
})
const containerRef = ref({})
const realtimeProfit = ref(0)
const telegraph = ref([])
const groupList = ref([])
const officialStatement= ref("")
const marketStatus = ref('')
let marketStatusTimer = null

const downloadState = ref({
  active: false, percentage: 0, speed: 0, avgSpeed: 0,
  downloaded: 0, total: 0, version: '', proxy: '',
  proxySpeed: 0, message: '', retrying: false,
})
let downloadNotification = null

function formatBytes(bytes) {
  if (!bytes || bytes <= 0) return '0 B'
  const units = ['B', 'KB', 'MB', 'GB']
  let val = bytes, i = 0
  while (val >= 1024 && i < units.length - 1) { val /= 1024; i++ }
  return val.toFixed(2) + ' ' + units[i]
}
function formatSpeed(bps) {
  if (!bps || bps <= 0) return '0 B/s'
  return formatBytes(bps) + '/s'
}
function renderDownloadContent() {
  const children = []
  if (downloadState.value.message) {
    children.push(h('div', {
      style: { 'margin-bottom': '8px', 'color': '#999', 'font-size': '12px', 'white-space': 'pre-wrap', 'max-height': '120px', 'overflow': 'hidden' }
    }, { default: () => downloadState.value.message }))
  }
  children.push(h(NProgress, {
    type: 'line',
    status: downloadState.value.retrying ? 'warning' : 'success',
    percentage: Math.round(downloadState.value.percentage),
    showIndicator: false,
    height: 8,
    borderRadius: 4,
  }))
  const detail = downloadState.value.retrying
    ? '正在尝试其他下载源...'
    : `${formatBytes(downloadState.value.downloaded)} / ${formatBytes(downloadState.value.total)} · ${formatSpeed(downloadState.value.speed)}`
  children.push(h('div', {
    style: { 'margin-top': '6px', 'font-size': '12px', 'color': '#888' }
  }, { default: () => detail }))
  if (downloadState.value.proxy) {
    children.push(h('div', {
      style: { 'margin-top': '2px', 'font-size': '11px', 'color': '#aaa' }
    }, { default: () => `下载源: ${downloadState.value.proxy}` }))
  }
  return h('div', { style: { 'text-align': 'left', 'font-size': '14px', 'min-width': '280px' } }, { default: () => children })
}

const investmentMottos = [
  "投资有风险，入市需谨慎",
  "别人贪婪我恐惧，别人恐惧我贪婪",
  "股市有风险，投资需谨慎",
  "不要把所有鸡蛋放在一个篮子里",
  "时间是优秀企业的朋友",
  "买股票就是买公司",
  "市场短期是投票机，长期是称重机",
  "保住本金是投资的第一要务",
  "在别人恐慌时贪婪，在别人贪婪时恐慌",
  "风险来自于你不知道自己在做什么",
  "价格是你付出的，价值是你得到的",
  "投资最重要的品质是耐心",
  "机会总是留给有准备的人",
  "知行合一，方能致远",
  "顺势而为，逆势而思",
  "投资是一场马拉松，不是百米冲刺",
  "独立思考是投资成功的关键",
  "市场永远在波动，但价值终将回归",
  "控制风险比追求收益更重要",
  "学习是最好的投资",
]
const currentMotto = ref(investmentMottos[Math.floor(Math.random() * investmentMottos.length)])

function refreshMotto() {
  currentMotto.value = investmentMottos[Math.floor(Math.random() * investmentMottos.length)]
}

function updateMarketStatus() {
  Promise.all([
    IsTradingTime().catch(() => false),
    IsHKTradingTime().catch(() => false),
    IsUSTradingTime().catch(() => false)
  ]).then(([cn, hk, us]) => {
    const parts = []
    parts.push(cn ? 'A股交易中' : 'A股休市')
    parts.push(hk ? '港股交易中' : '港股休市')
    parts.push(us ? '美股交易中' : '美股休市')
    marketStatus.value = parts.join(' | ')
    WindowSetTitle("go-stock " + marketStatus.value + " " + officialStatement.value + "  「" + currentMotto.value + "」  [数据来源于网络，仅供参考；投资有风险，入市需谨慎]")
  })
}

/** 用于功能权限：仅在赞助有效期内为解密等级，否则为 0（与 EffectiveSponsorVipStatus 一致） */
const vipLevel = ref(0)
/** 未生效原因，用于向用户解释为什么 VIP2 权益仍被拦截（如"尚未生效/已到期"） */
const vipInactiveReason = ref('')
let discreteMessage = null
function getDiscreteMessage() {
  if (!discreteMessage) {
    discreteMessage = createDiscreteApi(['message'], {
      configProviderProps: {
        theme: enableDarkTheme.value ? darkTheme : lightTheme,
      },
    })
  }
  return discreteMessage.message
}
async function refreshEffectiveVip() {
  try {
    const r = await GetEffectiveSponsorVip()
    const active = !!r?.active
    const lvl = Number(r?.vipLevel ?? 0)
    vipLevel.value = active && !Number.isNaN(lvl) ? lvl : 0
    vipInactiveReason.value = active ? '' : String(r?.reason ?? '')
  } catch (_) {
    vipLevel.value = 0
    vipInactiveReason.value = ''
  }
}
async function handleKlineAnalysisClick() {
  // [local-patch] 解锁K线分析菜单入口，跳过VIP校验
  activeKey.value = 'klineAnalysis'
  router.push({ name: 'klineAnalysis' })
}

const menuOptions = ref([
  {
    label: () =>
        h(
            RouterLink,
            {
              to: {
                name: 'home',
                params: {},
              },
              onClick: () => {
                activeKey.value = 'home'
              },
            },
            {default: () => '首页',}
        ),
    key: 'home',
    icon: renderIcon(HomeOutline),
  },
  {
    label: () =>
        h(
            RouterLink,
            {
              to: {
                name: 'stock',
                query: {
                  groupName: '全部',
                  groupId: 0,
                },
                params: {},
              },
              onClick: () => {
                activeKey.value = 'stock'
              },
            },
            {default: () => '股票自选',}
        ),
    key: 'stock',
    icon: renderIcon(StarOutline),
    children: [
      {
        label: () =>
            h(
                RouterLink,
                {
                  to: {
                    name: 'stock',
                    query: {
                      groupName: '全部',
                      groupId: 0,
                    },
                  },
                  onClick: () => {
                    activeKey.value = 'stock'
                    EventsEmit("changeTab", {ID: 0, name: '全部'})
                  },
                },
                {default: () => '全部',}
            ),
        key: 0,
      }
    ],
  },
  {
    label: () =>
        h(
            RouterLink,
            {
              href: '#',
              to: {
                name: 'market',
                params: {}
              },
              onClick: () => {
                activeKey.value = 'market'
                EventsEmit("changeMarketTab", {ID: 0, name: '市场快讯'})
              },
            },
            {default: () => '市场行情'}
        ),
    key: 'market',
    icon: renderIcon(NewspaperOutline),
    children: [
      {
        label: () =>
            h(
                RouterLink,
                {
                  href: '#',
                  to: {
                    name: 'market',
                    query: {
                      name: "市场快讯",
                    }
                  },
                  onClick: () => {
                    activeKey.value = 'market'
                    EventsEmit("changeMarketTab", {ID: 0, name: '市场快讯'})
                  },
                },
                {default: () => '市场快讯',}
            ),
        key: 'market1',
        icon: renderIcon(NewspaperSharp),
      },
      {
        label: () =>
            h(
                RouterLink,
                {
                  href: '#',
                  to: {
                    name: 'market',
                    query: {
                      name: "政策新闻",
                    }
                  },
                  onClick: () => {
                    activeKey.value = 'market'
                    EventsEmit("changeMarketTab", {ID: 0, name: '政策新闻'})
                  },
                },
                {default: () => '政策新闻',}
            ),
        key: 'market1_1',
        icon: renderIcon(DocumentTextOutline),
      },
      {
        label: () =>
            h(
                RouterLink,
                {
                  href: '#',
                  to: {
                    name: 'market',
                    query: {
                      name: "全球股指",
                    },
                  },
                  onClick: () => {
                    activeKey.value = 'market'
                    EventsEmit("changeMarketTab", {ID: 0, name: '全球股指'})
                  },
                },
                {default: () => '全球股指',}
            ),
        key: 'market2',
        icon: renderIcon(BarChartSharp),
      },
      {
        label: () =>
            h(
                RouterLink,
                {
                  href: '#',
                  to: {
                    name: 'market',
                    query: {
                      name: "重大指数",
                    }
                  },
                  onClick: () => {
                    activeKey.value = 'market'
                    EventsEmit("changeMarketTab", {ID: 0, name: '重大指数'})
                  },
                },
                {default: () => '重大指数',}
            ),
        key: 'market3',
        icon: renderIcon(AnalyticsOutline),
      },
      {
        label: () =>
            h(
                RouterLink,
                {
                  href: '#',
                  to: {
                    name: 'market',
                    query: {
                      name: "期指多空",
                    }
                  },
                  onClick: () => {
                    activeKey.value = 'market'
                    EventsEmit("changeMarketTab", {ID: 0, name: '期指多空'})
                  },
                },
                {default: () => '期指多空',}
            ),
        key: 'market3_1',
        icon: renderIcon(ScaleOutline),
      },
      {
        label: () =>
            h(
                RouterLink,
                {
                  href: '#',
                  to: {
                    name: 'market',
                    query: {
                      name: "行业排名",
                    }
                  },
                  onClick: () => {
                    activeKey.value = 'market'
                    EventsEmit("changeMarketTab", {ID: 0, name: '行业排名'})
                  },
                },
                {default: () => '行业排名',}
            ),
        key: 'market4',
        icon: renderIcon(Flag),
      },
      {
        label: () =>
            h(
                RouterLink,
                {
                  href: '#',
                  to: {
                    name: 'market',
                    query: {
                      name: "个股资金流向",
                    }
                  },
                  onClick: () => {
                    activeKey.value = 'market'
                    EventsEmit("changeMarketTab", {ID: 0, name: '个股资金流向'})
                  },
                },
                {default: () => '个股资金流向',}
            ),
        key: 'market5',
        icon: renderIcon(Pulse),
      },
      {
        label: () =>
            h(
                RouterLink,
                {
                  href: '#',
                  to: {
                    name: 'market',
                    query: {
                      name: "板块资金流向",
                    }
                  },
                  onClick: () => {
                    activeKey.value = 'market'
                    EventsEmit("changeMarketTab", {ID: 0, name: '板块资金流向'})
                  },
                },
                {default: () => '板块资金流向',}
            ),
        key: 'market5_1',
        icon: renderIcon(ReportMoney),
      },
      {
        label: () =>
            h(
                RouterLink,
                {
                  href: '#',
                  to: {
                    name: 'market',
                    query: {
                      name: "概念资金流向",
                    }
                  },
                  onClick: () => {
                    activeKey.value = 'market'
                    EventsEmit("changeMarketTab", {ID: 0, name: '概念资金流向'})
                  },
                },
                {default: () => '概念资金流向',}
            ),
        key: 'market5_2',
        icon: renderIcon(TrendingUp),
      },
      {
        label: () =>
            h(
                RouterLink,
                {
                  href: '#',
                  to: {
                    name: 'market',
                    query: {
                      name: "龙虎榜",
                    }
                  },
                  onClick: () => {
                    activeKey.value = 'market'
                    EventsEmit("changeMarketTab", {ID: 0, name: '龙虎榜'})
                  },
                },
                {default: () => '龙虎榜',}
            ),
        key: 'market6',
        icon: renderIcon(Dragon),
      },
      {
        label: () =>
            h(
                RouterLink,
                {
                  href: '#',
                  to: {
                    name: 'market',
                    query: {
                      name: "游资动向",
                    }
                  },
                  onClick: () => {
                    activeKey.value = 'market'
                    EventsEmit("changeMarketTab", {ID: 0, name: '游资动向'})
                  },
                },
                {default: () => '游资动向',}
            ),
        key: 'market6_1',
        icon: renderIcon(Fire),
      },
      {
        label: () =>
            h(
                RouterLink,
                {
                  href: '#',
                  to: {
                    name: 'market',
                    query: {
                      name: "个股研报",
                    }
                  },
                  onClick: () => {
                    activeKey.value = 'market'
                    EventsEmit("changeMarketTab", {ID: 0, name: '个股研报'})
                  },
                },
                {default: () => '个股研报',}
            ),
        key: 'market7',
        icon: renderIcon(StockOutlined),
      },
      {
        label: () =>
            h(
                RouterLink,
                {
                  href: '#',
                  to: {
                    name: 'market',
                    query: {
                      name: "公司公告",
                    }
                  },
                  onClick: () => {
                    activeKey.value = 'market'
                    EventsEmit("changeMarketTab", {ID: 0, name: '公司公告'})
                  },
                },
                {default: () => '公司公告',}
            ),
        key: 'market8',
        icon: renderIcon(NotificationFilled),
      },
      {
        label: () =>
            h(
                RouterLink,
                {
                  href: '#',
                  to: {
                    name: 'market',
                    query: {
                      name: "行业研究",
                    }
                  },
                  onClick: () => {
                    activeKey.value = 'market'
                    EventsEmit("changeMarketTab", {ID: 0, name: '行业研究'})
                  },
                },
                {default: () => '行业研究',}
            ),
        key: 'market9',
        icon: renderIcon(ReportSearch),
      },
      {
        label: () =>
            h(
                RouterLink,
                {
                  href: '#',
                  to: {
                    name: 'market',
                    query: {
                      name: "当前热门",
                    }
                  },
                  onClick: () => {
                    activeKey.value = 'market'
                    EventsEmit("changeMarketTab", {ID: 0, name: '当前热门'})
                  },
                },
                {default: () => '当前热门',}
            ),
        key: 'market10',
        icon: renderIcon(Gripfire),
      },
      {
        label: () =>
            h(
                RouterLink,
                {
                  href: '#',
                  to: {
                    name: 'market',
                    query: {
                      name: "名站优选",
                    }
                  },
                  onClick: () => {
                    activeKey.value = 'market'
                    EventsEmit("changeMarketTab", {ID: 0, name: '名站优选'})
                  },
                },
                {default: () => '名站优选',}
            ),
        key: 'market11',
        icon: renderIcon(FirefoxBrowser),
      },
      {
        label: () =>
            h(
                RouterLink,
                {
                  href: '#',
                  to: {
                    name: 'market',
                    query: {
                      name: "融资融券",
                    }
                  },
                  onClick: () => {
                    activeKey.value = 'market'
                    EventsEmit("changeMarketTab", {ID: 0, name: '融资融券'})
                  },
                },
                {default: () => '融资融券',}
            ),
        key: 'market12',
        icon: renderIcon(Wallet),
      },
    ]
  },
  {
    label: () =>
        h(
            'div',
            {
              style: 'cursor: pointer; width: 100%;',
              onClick: () => { handleKlineAnalysisClick() },
            },
            {default: () => 'K线分析'}
        ),
    key: 'klineAnalysis',
    icon: renderIcon(StatsChartOutline),
  },
  {
    label: () =>
        h(
            RouterLink,
            {
              to: {name: 'contracts'},
              onClick: () => {
                activeKey.value = 'contracts'
              },
            },
            {default: () => '合约行情'}
        ),
    show: !isCustomBuild.value && enableContracts.value,
    key: 'contracts',
    icon: renderIcon(SwapHorizontalOutline),
  },
  {
    label: () =>
        h(
            RouterLink,
            {
              to: {
                name: 'fund',
                query: {
                  name: '基金自选',
                },
              },
              onClick: () => {
                activeKey.value = 'fund'
              },
            },
            {default: () => '基金自选',}
        ),
    show: enableFund.value,
    key: 'fund',
    icon: renderIcon(SparklesOutline),
    children: [
      {
        label: () =>
            h(
                RouterLink,
                {
                  to: {name: 'fund', query: {name: '基金自选'}},
                  onClick: () => {
                    activeKey.value = 'fund'
                    EventsEmit("changeFundTab", {name: '基金自选'})
                  },
                },
                {default: () => '基金自选'}
            ),
        key: 'fundFollow',
        icon: renderIcon(StarOutline),
      },
      {
        label: () =>
            h(
                RouterLink,
                {
                  to: {name: 'fund', query: {name: '基金排行'}},
                  onClick: () => {
                    activeKey.value = 'fund'
                    EventsEmit("changeFundTab", {name: '基金排行'})
                  },
                },
                {default: () => '基金排行'}
            ),
        key: 'fundRanking',
        icon: renderIcon(TrendingUp),
      },
    ]
  },
  {
    label: () =>
        h(
            RouterLink,
            {
              to: {
                name: 'dailyReview',
                params: {},
              },
              onClick: () => {
                activeKey.value = 'dailyReview'
              },
            },
            {default: () => '复盘策略'}
        ),
    key: 'reviewStrategy',
    icon: renderIcon(CalendarOutline),
    children: [
      {
        label: () =>
            h(
                RouterLink,
                {
                  to: {
                    name: 'dailyReview',
                    params: {},
                  },
                  onClick: () => {
                    activeKey.value = 'dailyReview'
                  },
                },
                {default: () => '每日复盘'}
            ),
        key: 'dailyReview',
        icon: renderIcon(AnalyticsOutline),
      },
      {
        label: () =>
            h(
                RouterLink,
                {
                  to: {
                    name: 'morningStrategy',
                    params: {},
                  },
                  onClick: () => {
                    activeKey.value = 'morningStrategy'
                  },
                },
                {default: () => '盘前策略'}
            ),
        key: 'morningStrategy',
        icon: renderIcon(TimeOutline),
      },
      {
        label: () =>
            h(
                RouterLink,
                {
                  to: {
                    name: 'promptBacktest',
                    params: {},
                  },
                  onClick: () => {
                    activeKey.value = 'promptBacktest'
                  },
                },
                {default: () => '提示词回测(beta)'}
            ),
        key: 'promptBacktest',
        icon: renderIcon(StatsChartOutline),
      },
      {
        label: () =>
            h(
                RouterLink,
                {
                  to: {
                    name: 'recommendBacktestStats',
                    params: {},
                  },
                  onClick: () => {
                    activeKey.value = 'recommendBacktestStats'
                  },
                },
                {default: () => '推荐回测统计'}
            ),
        key: 'recommendBacktestStats',
        icon: renderIcon(AnalyticsOutline),
      },
    ]
  },
  {
    label: () =>
        h(
            RouterLink,
            {
              to: {
                name: 'agent',
                query: {
                  name:"Ai智能体",
                },
                onClick: () => {
                  activeKey.value = 'agent'
                },
              }
            },
            {default: () => 'Ai智能体'}
        ),
    key: 'agent',
    show:enableAgent.value,
    icon: renderIcon(Robot),
  },
    {
      label: () =>
          h(
              RouterLink,
              {
                to: {
                  name: 'research',
                  query: {
                    name:"研究中心",
                  },
                },
                onClick: () => {
                  activeKey.value = 'research'
                  setTimeout(() => {
                    EventsEmit("changeResearchTab", {ID: 0, name: 'AI分析报告'})
                  }, 100)
                },
              },
              {default: () => '研究中心'}
          ),
      key: 'research',
      icon: renderIcon(FlaskOutline),
      children:[
          {
            label: () =>
                h(
                    RouterLink,
                    {
                      to: {
                        name: 'research',
                        query: {
                          name:"AI分析报告",
                        },
                      },
                      onClick: () => {
                        activeKey.value = 'research'
                        setTimeout(() => {
                          EventsEmit("changeResearchTab", {ID: 0, name: 'AI分析报告'})
                        }, 100)
                      },
                    },
                    {default: () => 'AI分析报告'}
                ),
            key: 'research1',
            icon: renderIcon(ReportAnalytics),
          },
        {
          label: () =>
              h(
                  RouterLink,
                  {
                    to: {
                      name: 'research',
                      query: {
                        name:"股票推荐记录",
                      },
                    },
                    onClick: () => {
                      activeKey.value = 'research'
                      setTimeout(() => {
                        EventsEmit("changeResearchTab", {ID: 1, name: '股票推荐记录'})
                      }, 100)
                    },
                  },
                  {default: () => '股票推荐记录'}
              ),
          key: 'research2',
          icon: renderIcon(Star),
        },
        {
          label: () =>
              h(
                  RouterLink,
                  {
                    to: {
                      name: 'research',
                      query: {
                        name:"异动监控",
                      },
                    },
                    onClick: () => {
                      activeKey.value = 'research'
                      setTimeout(() => {
                        EventsEmit("changeResearchTab", {ID: 2, name: '异动监控'})
                      }, 100)
                    },
                  },
                  {default: () => '异动监控'}
              ),
          key: 'stockChanges',
          icon: renderIcon(TrendingUp),
        },
        {
          label: () =>
              h(
                  RouterLink,
                  {
                    to: {
                      name: 'research',
                      query: {
                        name:"涨停梯队",
                      },
                    },
                    onClick: () => {
                      activeKey.value = 'research'
                      setTimeout(() => {
                        EventsEmit("changeResearchTab", {ID: 9, name: '涨停梯队'})
                      }, 100)
                    },
                  },
                  {default: () => '涨停梯队'}
              ),
          key: 'uplimitLadder',
          icon: renderIcon(LocalFireDepartmentRound),
        },
        {
          label: () =>
              h(
                  RouterLink,
                  {
                    to: {
                      name: 'research',
                      query: {
                        name:"提示词模板",
                      },
                    },
                    onClick: () => {
                      activeKey.value = 'research'
                      setTimeout(() => {
                        EventsEmit("changeResearchTab", {ID: 3, name: '提示词模板'})
                      }, 100)
                    },
                  },
                  {default: () => '提示词模板'}
              ),
          key: 'research3',
          icon: renderIcon(Prompt),
        },
        {
          label: () =>
              h(
                  RouterLink,
                  {
                    to: {
                      name: 'research',
                      query: {
                        name:"提示词广场",
                      },
                    },
                    onClick: () => {
                      activeKey.value = 'research'
                      setTimeout(() => {
                        EventsEmit("changeResearchTab", {ID: 10, name: '提示词广场'})
                      }, 100)
                    },
                  },
                  {default: () => '提示词广场'}
              ),
          key: 'promptPlaza',
          icon: renderIcon(GlobeOutline),
        },
        {
          label: () =>
              h(
                  RouterLink,
                  {
                    to: {
                      name: 'research',
                      query: {
                        name:"问答广场",
                      },
                    },
                    onClick: () => {
                      activeKey.value = 'research'
                      setTimeout(() => {
                        EventsEmit("changeResearchTab", {ID: 11, name: '问答广场'})
                      }, 100)
                    },
                  },
                  {default: () => '问答广场'}
              ),
          key: 'promptQa',
          icon: renderIcon(ChatbubblesOutline),
        },
        {
          label: () =>
              h(
                  RouterLink,
                  {
                    to: {
                      name: 'research',
                      query: {
                        name:"形态选股",
                      },
                    },
                    onClick: () => {
                      activeKey.value = 'research'
                      setTimeout(() => {
                        EventsEmit("changeResearchTab", {ID: 3, name: '形态选股'})
                      }, 100)
                    },
                  },
                  {default: () => '形态选股'}
              ),
          key: 'research4',
          icon: renderIcon(SearchOutline),
        },
        {
          label: () =>
              h(
                  RouterLink,
                  {
                    to: {
                      name: 'research',
                      query: {
                        name:"指标选股",
                      },
                    },
                    onClick: () => {
                      activeKey.value = 'research'
                      setTimeout(() => {
                        EventsEmit("changeResearchTab", {ID: 0, name: '指标选股'})
                      }, 100)
                    },
                  },
                  {default: () => '指标选股'}
              ),
          key: 'research_select_stock',
          icon: renderIcon(BoxSearch20Regular),
        },
        {
          label: () =>
              h(
                  RouterLink,
                  {
                    to: {
                      name: 'research',
                      query: {
                        name:"定时任务",
                      },
                    },
                    onClick: () => {
                      activeKey.value = 'research'
                      setTimeout(() => {
                        EventsEmit("changeResearchTab", {ID: 5, name: '定时任务'})
                      }, 100)
                    },
                  },
                  {default: () => '定时任务'}
              ),
          key: 'research5',
          icon: renderIcon(TimeOutline),
        },
        {
          label: () =>
              h(
                  RouterLink,
                  {
                    to: {
                      name: 'research',
                      query: {
                        name:"交易日志",
                      },
                    },
                    onClick: () => {
                      activeKey.value = 'research'
                      setTimeout(() => {
                        EventsEmit("changeResearchTab", {ID: 6, name: '交易日志'})
                      }, 100)
                    },
                  },
                  {default: () => '交易日志(beta)'}
              ),
          key: 'research6',
          icon: renderIcon(MoneyCollectOutlined),
        },
        {
          label: () =>
              h(
                  RouterLink,
                  {
                    to: {
                      name: 'research',
                      query: {
                        name:"每日操作计划",
                      },
                    },
                    onClick: () => {
                      activeKey.value = 'research'
                      setTimeout(() => {
                        EventsEmit("changeResearchTab", {ID: 7, name: '每日操作计划'})
                      }, 100)
                    },
                  },
                  {default: () => '每日操作计划'}
              ),
          key: 'dailyOperationPlan',
          icon: renderIcon(CalendarOutline),
        },
        {
          label: () =>
              h(
                  RouterLink,
                  {
                    to: {
                      name: 'research',
                    },
                    onClick: () => {
                      activeKey.value = 'research'
                      setTimeout(() => {
                        EventsEmit("changeResearchTab", {ID: 7, name: 'MCP服务'})
                      }, 100)
                    },
                  },
                  {default: () => 'MCP服务'}
              ),
          key: 'mcpServers',
          icon: renderIcon(ServerOutline),
        },
        {
          label: () =>
              h(
                  RouterLink,
                  {
                    to: {
                      name: 'research',
                    },
                    onClick: () => {
                      activeKey.value = 'research'
                      setTimeout(() => {
                        EventsEmit("changeResearchTab", {ID: 8, name: '技能管理'})
                      }, 100)
                    },
                  },
                  {default: () => '技能管理'}
              ),
          key: 'skills',
          icon: renderIcon(FlashOutline),
        },
        {
          label: () =>
              h(
                  RouterLink,
                  {
                    to: {
                      name: 'research',
                    },
                    onClick: () => {
                      activeKey.value = 'research'
                      setTimeout(() => {
                        EventsEmit("changeResearchTab", {ID: 9, name: '知识库管理'})
                      }, 100)
                    },
                  },
                  {default: () => '知识库管理'}
              ),
          key: 'knowledgeBase',
          icon: renderIcon(BookOutline),
        },
      ],
    },
  {
    label: '设置',
    key: 'settings',
    icon: renderIcon(SettingsOutline),
    children: [
      {
        label: () =>
            h(
                RouterLink,
                {
                  to: {
                    name: 'settings',
                    query: {
                      name:"设置",
                    },
                  },
                  onClick: () => {
                    activeKey.value = 'settings'
                  },
                },
                {default: () => '基础设置'}
            ),
        key: 'settings',
        icon: renderIcon(SettingsOutline),
      },
      {
        label: () =>
            h(
                RouterLink,
                {
                  to: {
                    name: 'aiConfigs',
                    query: {
                      name:"AI模型服务",
                    },
                  },
                  onClick: () => {
                    activeKey.value = 'aiConfigs'
                  },
                },
                {default: () => 'AI模型服务'}
            ),
        key: 'aiConfigs',
        icon: renderIcon(SparklesOutline),
      },
      {
        label: () =>
            h(
                RouterLink,
                {
                  to: {
                    name: 'userProfile',
                    query: {
                      name:"我的画像",
                    },
                  },
                  onClick: () => {
                    activeKey.value = 'userProfile'
                  },
                },
                {default: () => '我的画像'}
            ),
        key: 'userProfile',
        icon: renderIcon(BookmarkOutline),
      },
    ],
  },
  {
    label: () =>
        h(
            RouterLink,
            {
              to: {
                name: 'about',
                query: {
                  name:"关于",
                }
              },
              onClick: () => {
                activeKey.value = 'about'
              },
            },
            {default: () => '关于'}
        ),
    key: 'about',
    icon: renderIcon(LogoGithub),
    show: true,
  },
  {
    show:false,
    label: () => h("a", {
      href: '#',
      onClick: toggleFullscreen,
      title: '全屏 Ctrl+F 退出全屏 Esc',
    }, {default: () => isFullscreen.value ? '取消全屏' : '全屏'}),
    key: 'full',
    icon: renderIcon(ExpandOutline),
  },
  // {
  //   label: ()=> h("a", {
  //     href: 'javascript:void(0)',
  //     style: 'cursor: move;',
  //     onClick: toggleStartMoveWindow,
  //   }, { default: () => '移动' }),
  //   key: 'move',
  //   icon: renderIcon(MoveOutline),
  // },
  {
    label: () => h("a", {
      href: '#',
      onClick: Hide,
    }, {default: () => '隐藏至托盘区'}),
    key: 'hide',
    icon: renderIcon(SlideHide24Filled),
  },
  {
    label: () => h("a", {
      href: '#',
      onClick: Quit,
    }, {default: () => '退出程序'}),
    key: 'exit',
    icon: renderIcon(PowerOutline),
  },
])

// 重建"股票自选"菜单的分组子项（保留"全部"，用最新分组列表替换其余子项）
function refreshStockGroupMenu() {
  GetGroupList().then(result => {
    groupList.value = result
    menuOptions.value.forEach((item) => {
      if (item.key === 'stock') {
        const allItem = item.children.find(c => c.key === 0)
        item.children = allItem ? [allItem] : []
        item.children.push(...groupList.value.map(g => {
          return {
            label: () =>
                h(
                    RouterLink,
                    {
                      to: {
                        name: 'stock',
                        query: {
                          groupName: g.name,
                          groupId: g.ID,
                        },
                      },
                      onClick: () => {
                        activeKey.value = 'stock'
                        setTimeout(() => {
                          EventsEmit("changeTab", g)
                        }, 100)
                      },
                    },
                    {default: () => g.name,}
                ),
            key: g.ID,
          }
        }))
      }
    })
  }).catch(err => {
    console.error("refreshStockGroupMenu error:", err)
  })
}

function renderIcon(icon) {
  return () => h(NIcon, null, {default: () => h(icon)})
}

function toggleFullscreen(e) {
  activeKey.value = 'full'
  //console.log(e)
  if (isFullscreen.value) {
    WindowUnfullscreen()
    //e.target.innerHTML = '全屏'
  } else {
    WindowFullscreen()
    // e.target.innerHTML = '取消全屏'
  }
  isFullscreen.value = !isFullscreen.value
}

// const drag = ref(false)
// const lastPos= ref({x:0,y:0})
// function toggleStartMoveWindow(e) {
//   drag.value=!drag.value
//   lastPos.value={x:e.clientX,y:e.clientY}
// }
// function dragstart(e) {
//   if (drag.value) {
//     let x=e.clientX-lastPos.value.x
//     let y=e.clientY-lastPos.value.y
//     WindowGetPosition().then((pos) => {
//       WindowSetPosition(pos.x+x,pos.y+y)
//     })
//   }
// }
// window.addEventListener('mousemove', dragstart)

EventsOn("realtime_profit", (data) => {
  realtimeProfit.value = data
})
EventsOn("telegraph", (data) => {
  telegraph.value = data
})

EventsOn("loadingMsg", (data) => {
  if(data==="done"){
    loadingMsg.value = "加载完成..."
    EventsEmit("loadingDone", "app")
    loading.value  = false
  }else{
    loading.value  = true
    loadingMsg.value = data
  }
})

setTimeout(() => {
  if (loading.value) {
    loading.value = false
    loadingMsg.value = "加载完成..."
    EventsEmit("loadingDone", "app")
  }
}, 8000)

onBeforeUnmount(() => {
  if (marketStatusTimer) {
    clearInterval(marketStatusTimer)
    marketStatusTimer = null
  }
  EventsOff("realtime_profit")
  EventsOff("loadingMsg")
  EventsOff("telegraph")
  EventsOff("newsPush")
  EventsOff("dailyReviewGenerated")
  EventsOff("morningStrategyGenerated")
  EventsOff("groupListChanged")
  EventsOff("updateDownloadStart")
  EventsOff("downloadProgress")
  EventsOff("updateDownloadComplete")
  EventsOff("updateDownloadFailed")
  EventsOff("updateApplied")
})

window.onerror = function (msg, source, lineno, colno, error) {
  // 将错误信息发送给后端
  EventsEmit("frontendError", {
    page: "App.vue",
    message: msg,
    source: source,
    lineno: lineno,
    colno: colno,
    error: error ? error.stack : null,
  });
  return true;
};

onBeforeMount(() => {
  GetVersionInfo().then(result => {
    if(result.officialStatement){
      content.value = result.officialStatement+"\n\n"+content.value
    }
    officialStatement.value = result.officialStatement || ""
    isCustomBuild.value = result.customBuild === true
    if (result.customBuild) {
      // 定制版本编译（wails build -tags custom）：隐藏"关于"与"合约行情"菜单
      menuOptions.value.forEach((item) => {
        if (item.key === 'about' || item.key === 'contracts') {
          item.show = false
        }
      })
    }
    updateMarketStatus()
  }).catch(err => {
    console.error("GetVersionInfo error:", err)
  })

  refreshStockGroupMenu()
  // 监听分组变化（新增/改名/删除），实时刷新菜单栏
  EventsOn("groupListChanged", () => {
    refreshStockGroupMenu()
  })


  GetConfig().then((res) => {
    enableFund.value = res.enableFund
    enableAgent.value = res.enableAgent
    enableContracts.value = res.enableContracts !== false

    menuOptions.value.filter((item) => {
      if (item.key === 'fund') {
        item.show = res.enableFund
      }
      if (item.key === 'agent') {
        item.show = res.enableAgent
      }
      if (item.key === 'contracts') {
        item.show = !isCustomBuild.value && enableContracts.value
      }
    })

    if (res.darkTheme) {
      enableDarkTheme.value = darkTheme
    } else {
      enableDarkTheme.value = null
    }
  }).catch(err => {
    console.error("GetConfig error:", err)
  })
})

onMounted(() => {
  updateMarketStatus()
  marketStatusTimer = setInterval(() => {
    refreshMotto()
    updateMarketStatus()
  }, 60000)
  contentStyle.value = "max-height: calc(92vh);overflow: hidden"
  GetConfig().then((res) => {
    if (res.enableNews) {
      enableNews.value = true
    }
    enableFund.value = res.enableFund
    enableAgent.value = res.enableAgent
    enableContracts.value = res.enableContracts !== false
    const {notification, dialog } =createDiscreteApi(["notification","dialog"], {
      configProviderProps: {
        theme: enableDarkTheme.value ? darkTheme : lightTheme ,
        max: 3,
      },
    })
    EventsOn("newsPush", (data) => {
      //console.log(data)
      if(data.isRed){
        notification.create({
          //type:"error",
         // avatar: () => h(NIcon,{component:Notifications,color:"red"}),
          title: data.time,
          content: () => h('div',{type:"error",style:{
              "text-align":"left",
              "font-size":"14px",
              "color":"#f67979"
            }}, { default: () => data.content }),
          meta: () => h(NText,{type:"warning"}, { default: () => data.source}),
          duration:1000*40,
        })
      }else{
         notification.create({
          //type:"info",
          //avatar: () => h(NIcon,{component:Notifications}),
          title: data.time,
          content: () => h('div',{type:"info",style:{
            "text-align":"left",
              "font-size":"14px",
              "color": data.source==="go-stock"?"#F98C24":"#549EC8"
            }}, { default: () => data.content }),
          meta: () => h(NText,{type:"warning"}, { default: () => data.source}),
          duration:1000*30 ,
        })
      }
    })

    EventsOn("dailyReviewGenerated", (data) => {
      if (!data) return
      if (data.status === 'failed') {
        notification.create({
          title: `每日复盘生成失败（${data.date}）`,
          content: () => h('div', {style: {"text-align": "left", "font-size": "14px", "color": "#f67979"}},
              {default: () => data.errorMessage || '未知错误'}),
          duration: 1000 * 30,
        })
      } else if (data.status === 'success') {
        notification.create({
          title: `每日复盘已生成（${data.date}）`,
          content: () => h('div', {style: {"text-align": "left", "font-size": "14px"}},
              {default: () => data.summary || ''}),
          duration: 1000 * 30,
        })
      }
    })

    EventsOn("morningStrategyGenerated", (data) => {
      if (!data) return
      if (data.status === 'failed') {
        notification.create({
          title: `盘前策略生成失败（${data.date}）`,
          content: () => h('div', {style: {"text-align": "left", "font-size": "14px", "color": "#f67979"}},
              {default: () => data.errorMessage || '未知错误'}),
          duration: 1000 * 30,
        })
      } else if (data.status === 'success') {
        notification.create({
          title: `盘前策略已生成（${data.date}）`,
          content: () => h('div', {style: {"text-align": "left", "font-size": "14px"}},
              {default: () => data.summary || ''}),
          duration: 1000 * 30,
        })
      }
    })

    EventsOn("updateDownloadStart", (data) => {
      downloadState.value = {
        active: true, percentage: 0, speed: 0, avgSpeed: 0,
        downloaded: 0, total: data.total || 0, version: data.version || '',
        proxy: data.proxy || '(直连)', proxySpeed: data.proxySpeed || 0,
        message: data.message || '', retrying: false,
      }
      if (downloadNotification) { downloadNotification.destroy(); downloadNotification = null }
      downloadNotification = notification.create({
        title: () => '正在下载新版本 ' + downloadState.value.version,
        content: renderDownloadContent,
        meta: () => h(NText, { type: 'warning' }, { default: () => 'go-stock' }),
        duration: 0,
      })
    })

    EventsOn("downloadProgress", (data) => {
      if (data.status === 'retrying') {
        downloadState.value.retrying = true
        downloadState.value.percentage = 0
        downloadState.value.downloaded = 0
        downloadState.value.speed = 0
        return
      }
      downloadState.value.retrying = false
      downloadState.value.percentage = data.percentage || 0
      downloadState.value.speed = data.speed || 0
      downloadState.value.avgSpeed = data.avgSpeed || 0
      downloadState.value.downloaded = data.downloaded || 0
      downloadState.value.total = data.total || 0
      if (data.proxy) {
        downloadState.value.proxy = data.proxy
      }
    })

    EventsOn("updateDownloadComplete", (data) => {
      downloadState.value.active = false
      downloadState.value.percentage = 100
      if (downloadNotification) { downloadNotification.destroy(); downloadNotification = null }
      notification.create({
        title: '版本下载完成',
        content: () => h('div', { style: { 'text-align': 'left', 'font-size': '14px', 'color': '#52c41a' } },
          { default: () => '新版本 ' + data.version + ' 下载完成，正在安装更新...' }),
        meta: () => h(NText, { type: 'warning' }, { default: () => 'go-stock' }),
        duration: 5000,
      })
    })

    // 更新安装就绪，弹出对话框让用户选择是否立即重启生效
    EventsOn("updateApplied", (data) => {
      dialog.warning({
        title: '更新已就绪',
        content: () => h('div', { style: { 'text-align': 'left', 'font-size': '14px' } },
          { default: () => '新版本 ' + (data?.version || '') + ' 已安装完成，重启应用后即可生效。是否立即重启？' }),
        positiveText: '立即重启',
        negativeText: '稍后重启',
        // 返回 promise 让按钮进入 loading 态：后端收尾（WAL checkpoint）期间用户可感知"正在重启"
        onPositiveClick: () =>
          RestartApp().catch(err => {
            console.error('RestartApp error:', err)
            notification.create({
              title: '重启失败',
              content: () => h('div', { style: { 'text-align': 'left', 'font-size': '14px', 'color': '#f67979' } },
                { default: () => '重启应用失败：' + err }),
              meta: () => h(NText, { type: 'warning' }, { default: () => 'go-stock' }),
              duration: 10000,
            })
          }),
      })
    })

    EventsOn("updateDownloadFailed", (data) => {
      downloadState.value.active = false
      if (downloadNotification) { downloadNotification.destroy(); downloadNotification = null }
      const items = [
        h('div', { style: { 'margin-bottom': '8px' } },
          { default: () => '新版本 ' + data.version + ' 自动下载失败: ' + data.error })
      ]
      if (data.manualLinks) {
        items.push(h('div', { style: { 'margin-bottom': '4px' } }, { default: () => '请手动下载后替换程序文件:' }))
        items.push(h('div', {
          style: { 'font-size': '12px', 'word-break': 'break-all', 'margin-bottom': '2px', 'color': '#549EC8' }
        }, { default: () => '加速镜像: ' + data.manualLinks.mirror }))
        items.push(h('div', {
          style: { 'font-size': '12px', 'word-break': 'break-all', 'color': '#549EC8' }
        }, { default: () => '原始地址: ' + data.manualLinks.original }))
      }
      notification.create({
        title: '版本下载失败',
        content: () => h('div', { style: { 'text-align': 'left', 'font-size': '14px', 'color': '#f67979' } },
          { default: () => items }),
        meta: () => h(NText, { type: 'warning' }, { default: () => 'go-stock' }),
        duration: 0,
      })
    })

  }).catch(err => {
    console.error("GetConfig(onMounted) error:", err)
  })
})
</script>
<template>
  <n-config-provider ref="containerRef" :theme="enableDarkTheme" :locale="zhCN" :date-locale="dateZhCN">
    <n-message-provider>
      <n-notification-provider>
        <n-modal-provider>
          <n-dialog-provider>
            <n-watermark
                :content="''"
                cross
                selectable
                :font-size="16"
                :line-height="16"
                :width="500"
                :height="400"
                :x-offset="50"
                :y-offset="150"
                :rotate="-15"
            >
<!--              <FloatingAiAssistant />-->
              <FloatingAgentAssistant />
              <!-- 信号监控面板在 custom 编译中保留（面板内部自行隐藏 OKX 双池页签与自动交易流水）；
                   普通编译完整显示 -->
              <SignalMonitorPanel />
              <n-flex>
                <n-grid x-gap="12" :cols="1">
                  <n-gi>
                    <n-spin :show="loading">
                      <template #description>
                        {{ loadingMsg }}
                      </template>
                      <n-marquee :speed="100" style="position: relative;top:0;z-index: 19;width: 100%"
                                 v-if="(telegraph.length>0)&&(enableNews)">
                        <n-tag type="warning" v-for="item in telegraph" style="margin-right: 10px">
                          {{ item }}
                        </n-tag>
                      </n-marquee>
                      <n-scrollbar :style="contentStyle">
                        <n-skeleton v-if="loading" height="calc(100vh)" />
                        <RouterView/>
                      </n-scrollbar>
                    </n-spin>
                  </n-gi>
                  <n-gi style="position: fixed;bottom:0;z-index: 9;width: 100%;">
                    <n-card size="small" style="--wails-draggable:no-drag">
                      <n-menu style="font-size: 18px;"
                              v-model:value="activeKey"
                              mode="horizontal"
                              :options="menuOptions"
                              :dropdown-props="{ menuProps: () => ({ style: 'max-height: 60vh; overflow-y: auto;' }) }"
                              responsive
                      />
                    </n-card>
                  </n-gi>
                </n-grid>
              </n-flex>
            </n-watermark>
          </n-dialog-provider>
        </n-modal-provider>
      </n-notification-provider>
    </n-message-provider>
  </n-config-provider>
</template>
<style>
/* 菜单/下拉弹出层滚动条样式（naive-ui 弹出层渲染到 body，需全局作用域） */
.n-dropdown-menu,
.n-dropdown-menu .n-vm-list,
.n-base-select-menu,
.n-base-select-menu .n-vm-list {
  scrollbar-width: thin;
  scrollbar-color: rgba(128, 128, 128, 0.45) transparent;
}
.n-dropdown-menu::-webkit-scrollbar,
.n-dropdown-menu .n-vm-list::-webkit-scrollbar,
.n-dropdown-menu .n-scrollbar-container::-webkit-scrollbar,
.n-base-select-menu::-webkit-scrollbar,
.n-base-select-menu .n-vm-list::-webkit-scrollbar,
.n-base-select-menu .n-scrollbar-container::-webkit-scrollbar {
  width: 6px;
  height: 6px;
}
.n-dropdown-menu::-webkit-scrollbar-thumb,
.n-dropdown-menu .n-vm-list::-webkit-scrollbar-thumb,
.n-dropdown-menu .n-scrollbar-container::-webkit-scrollbar-thumb,
.n-base-select-menu::-webkit-scrollbar-thumb,
.n-base-select-menu .n-vm-list::-webkit-scrollbar-thumb,
.n-base-select-menu .n-scrollbar-container::-webkit-scrollbar-thumb {
  background-color: rgba(128, 128, 128, 0.45);
  border-radius: 3px;
}
.n-dropdown-menu::-webkit-scrollbar-thumb:hover,
.n-dropdown-menu .n-vm-list::-webkit-scrollbar-thumb:hover,
.n-dropdown-menu .n-scrollbar-container::-webkit-scrollbar-thumb:hover,
.n-base-select-menu::-webkit-scrollbar-thumb:hover,
.n-base-select-menu .n-vm-list::-webkit-scrollbar-thumb:hover,
.n-base-select-menu .n-scrollbar-container::-webkit-scrollbar-thumb:hover {
  background-color: rgba(128, 128, 128, 0.7);
}
.n-dropdown-menu::-webkit-scrollbar-track,
.n-dropdown-menu .n-vm-list::-webkit-scrollbar-track,
.n-dropdown-menu .n-scrollbar-container::-webkit-scrollbar-track,
.n-base-select-menu::-webkit-scrollbar-track,
.n-base-select-menu .n-vm-list::-webkit-scrollbar-track,
.n-base-select-menu .n-scrollbar-container::-webkit-scrollbar-track {
  background: transparent;
}
</style>
